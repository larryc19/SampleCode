﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorldConsole
{
    class Program
    {
        static HttpClient client = new HttpClient();

   
        static void Main(string[] args)
        {
        }

        

        static void ShowMessage()
        {
            Console.WriteLine(GetMessage());
        }

        static async Task<string> GetMessage()
        {
           string path = "/api/Hello";
         string  message = null;
            HttpResponseMessage response = await client.GetAsync(path);
            if (response.IsSuccessStatusCode)
            {
              message = await response.Content.ReadAsStringAsync();
            }
            return message;
        }

    }
}
